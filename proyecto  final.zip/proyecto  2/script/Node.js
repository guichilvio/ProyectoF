const express = require('express');
const mysql = require('mysql'); // Usar mysql2 para promesas
const app = express();
const port = 3000;

(async () => {
    try {
        // Configuración de la conexión a la base de datos usando mysql2 y promesas
        const db = await mysql.createConnection({
            host: 'localhost',
            user: 'root',
            password: 'Admin123',
            database: 'cafe_internet',
            database: 'verdu',
            database: 'ferreteria', // Puedes cambiar a 'verdu' o 'ferreteria' dependiendo de cuál deseas conectar
        });

        console.log('Conexión a la base de datos exitosa');

        // Endpoint para obtener las computadoras
        app.get('/computadoras', async (req, res) => {
            try {
                const [results] = await db.query('SELECT * FROM computadoras');
                res.json(results);
            } catch (err) {
                console.error('Error al obtener computadoras:', err);
                res.status(500).send('Error al obtener computadoras');
            }
        });

        // Endpoint para iniciar una sesión de usuario
        app.post('/iniciar-sesion', async (req, res) => {
            try {
                const { nombre_usuario, id_computadora, tiempo_uso, costo_total } = req.body;
                const queryUsuario = 'INSERT INTO usuarios (nombre_usuario, tiempo_uso, costo_total, id_computadora) VALUES (?, ?, ?, ?)';
                await db.query(queryUsuario, [nombre_usuario, tiempo_uso, costo_total, id_computadora]);
                res.send('Sesión iniciada con éxito');
            } catch (err) {
                console.error('Error al iniciar sesión:', err);
                res.status(500).send('Error al iniciar sesión');
            }
        });

        app.listen(port, () => {
            console.log(`Servidor corriendo en http://localhost:${port}`);
        });
    } catch (err) {
        console.error('Error al conectar a la base de datos:', err);
    }
})();
